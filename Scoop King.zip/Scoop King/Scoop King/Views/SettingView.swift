//
//  SettingView.swift
//  Scoop King
//
//  Created by Tad Clifton on 12/3/24.
//

import SwiftUI

struct SettingView: View {
    var body: some View {
        Text("Settings")
    }
}

#Preview {
    SettingView()
}

